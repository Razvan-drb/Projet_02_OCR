def url_retriever():
    return None
